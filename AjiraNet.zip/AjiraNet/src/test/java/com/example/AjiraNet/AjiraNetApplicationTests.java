/*
package com.example.AjiraNet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AjiraNetApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/
